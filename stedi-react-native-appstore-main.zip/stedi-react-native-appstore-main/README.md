# To install and run
`npm install`

`npm start`

To do an IOS Testflight build:

`npx eas-cli build --profile production --platform ios`

When the build finishes, open the Transporter app on a Mac to upload to Testflight